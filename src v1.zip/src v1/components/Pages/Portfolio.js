import React from "react";

export const Portfolio = () => {
  return (
    <div>
      <h1>Portfolio</h1>
    </div>
  );
};
